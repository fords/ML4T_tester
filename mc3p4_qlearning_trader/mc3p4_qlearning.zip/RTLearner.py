"""
Template for implementing QLearner  (c) 2015 Tucker Balch
"""
# Zeyar Win zwin3
import pandas as pd
import numpy as np

class RTLearner(object):
    def __init__(self, leaf_size = 1, verbose = False):
        self.leaf_size = leaf_size
        self.verbose = verbose
        self.dataframe = None
        self.tree = None

    def author(self):
        return('zwin3')

    def get_dataframe(self):
        return(self.dataframe)

    def get_tree(self):
        return(self.tree)

    def addEvidence(self, Xtrain, Ytrain):

        dataframe = pd.DataFrame(Xtrain)
        dataframe['Y'] = Ytrain

        self.data = dataframe
        self.tree = self.build_tree(dataframe)
        self.query_tree = self.tree.copy()

    def build_tree(self, data):

        if data.shape[0] <= self.leaf_size or len(pd.unique(data.iloc[:,-1])) == 1:
            # randomly selects a leaf value if it is larger than 1
            return(np.array([-1, data.iloc[np.random.choice(range(data.shape[0])), -1], np.nan, np.nan]).reshape(1,4))

        else:
            feature = np.random.choice(data.columns[:-1])
            split1, split2 = np.random.choice(data.iloc[:,feature], size=2)
            split_val = (split1 + split2)/2.0
            while data[data.iloc[:, feature] <= split_val].shape[0] == data.shape[0] or\
                  data[data.iloc[:, feature] <= split_val].empty or\
                  data[data.iloc[:, feature] > split_val].empty:

                feature = np.random.choice(data.columns[:-1])
                split_val = data.iloc[:,feature].mean()

            left_tree  = self.build_tree(data[data.iloc[:, feature] <= split_val])
            right_tree = self.build_tree(data[data.iloc[:, feature] > split_val])
            root = [feature, split_val, 1, left_tree.shape[0] + 1]
            temp_tree = np.vstack([root, left_tree, right_tree])
            return(temp_tree)

    def query_value(self, values):
        current_pos = 0
        while True:
            tree_pos = self.tree[current_pos]
            if current_pos > self.tree.shape[0]:
                return('Error querying value')
            elif int(tree_pos[0]) == -1:
                return(tree_pos[1])
            elif values[int(tree_pos[0])] <= tree_pos[1]:
                current_pos += 1
            else:
                current_pos += int(tree_pos[3])

    def query(self,Xtest):
        try: # assumes multiple test values
            return([self.query_value(i) for i in Xtest])

        except:
            return([self.query_value(Xtest)])
